import React, { createContext , useState } from "react";
export let AuthContextApi = createContext();

let AuthProvider = ({ children }) => {
    let[isAuth , setisAuth] = useState(true)
    return (
        <AuthContextApi.Provider value={isAuth} >
            {children}
        </AuthContextApi.Provider>
    )
}
export default AuthProvider;