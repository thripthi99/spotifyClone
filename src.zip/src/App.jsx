import React , {useContext} from 'react'
import Navbar from './Pages/HeaderComponent/Navbar';

import {BrowserRouter as Router , Switch , Route} from "react-router-dom"
import Home from './Pages/Home';
import Login from './Components/AuthComponent/Login';
import Signup from './Components/AuthComponent/Signup';
import PageNotFound from './Pages/PageNotFound';
import { AuthContextApi } from './Api\'s/AuthContent';

const App = () => {
  let data = useContext(AuthContextApi);
    return (
      <section id="SpotifyMainBlock">
        <article>
          <Router>
            {data===true ? <header>
              <Navbar />
            </header>: ""}
            
            <main>
             
              {/* dynamic route starts here */}
              <Switch>
                <Route path="/" exact>
                  <Home />
                </Route>
                <Route path="/login" exact>
                  <Login />
                </Route>
                <Route path="/signup" exact>
                  <Signup />
                </Route>
                <Route path="*">
                  <PageNotFound />
                </Route>
              </Switch>
              {/* dynamic route Ends here */}
            </main>
          </Router>
        </article>
      </section>
    );
}

export default App
