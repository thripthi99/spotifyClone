import React from 'react'
import Logo from '../../Pages/HeaderComponent/Logo';


const Login = () => {
    return (
      <section id="authblock">
        <article>
                <h1>Login</h1>
                <Logo/>
        </article>
      </section>
    );
}

export default Login
